This code runs on Keras with Tensorflow backend, the following libraries are required:

    1. Jupyter notebook
    2. Keras-gpu
    3. Tensorflow-gpu


To successfully run this code, please modify the code based on the environment correspondingly.

    1. Select a GPU which you want to run this code in 
        os.environ['CUDA_VISIBLE_DEVICES'] = '1'
    2. Download the model and change the model path in 
        model.load_weights('train_output/salicon_generator_epoch_sigmoid25.h5')
    3. Run the jupyter blocks one by one and see the result.
