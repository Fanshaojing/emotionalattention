from metrics import calc_all

pred_sal_folder = './pred_sal_folder/'
gt_sal_folder = './gt_sal_folder/'
binary_folder = './binary_folder/'

calc_all(pred_sal_folder, gt_sal_folder, binary_folder, base='binary')
