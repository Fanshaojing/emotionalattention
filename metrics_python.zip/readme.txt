This code is the python implementation of saliency map metrics on MIT Saliency Benchmark (http://saliency.mit.edu), which has been tested on both Ubuntu and Windows, the speed of this code is about 5 times faster than the MATLAB version.

To successfully run this code, please install Anaconda and the following libraries:

	1. tqdm==4.19.9
	2. numpy
	3. scikit-image
	4. -c conda-forge pyemd==0.4.4

Instructions to run this code:

	1. change the pred_sal_folder (route to the predicted saliency map), gt_sal_folder (route to the ground truth fixation map) and binary_folder (route to the ground truth binary fixation map) in main.py correspondingly based on the environment.
	2. enter this folder and call “python main.py” in shell.

